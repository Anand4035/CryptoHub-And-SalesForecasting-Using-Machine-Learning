# 🚀 Crypto Hub - Complete Setup & Run Guide

## 📋 Quick Start (3 Steps)

### Step 1: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 2: Run the Application
```bash
python app.py
```

### Step 3: Open Your Browser
Visit: **http://127.0.0.1:8050**

---

## 📝 Detailed Setup Instructions

### Prerequisites

✅ **Required:**
- Python 3.8 or higher
- pip (Python package manager)
- Internet connection (for data fetching)

### Step-by-Step Installation

#### 1️⃣ **Navigate to Project Folder**
```bash
cd "C:\Users\krnan\python practice"
```
Or if you extracted the zip from Desktop:
```bash
cd "C:\Users\krnan\Desktop\Crypto_Hub_Project"
```

#### 2️⃣ **Install Python Dependencies**
```bash
pip install -r requirements.txt
```

**What this installs:**
- Flask (web framework)
- Dash (interactive web app)
- Pandas, NumPy (data processing)
- Scikit-learn (machine learning)
- yfinance (crypto data)
- Plotly (charts)
- BeautifulSoup4 (web scraping)
- And more...

#### 3️⃣ **Verify Installation**
```bash
python -c "import dash, pandas, sklearn; print('✅ All good!')"
```

#### 4️⃣ **Run the Application**
```bash
python app.py
```

You should see:
```
Dash is running on http://127.0.0.1:8050/
 * Serving Flask app 'app'
 * Debug mode: off
```

#### 5️⃣ **Open in Browser**
- The application should auto-open in your browser
- Or manually visit: **http://127.0.0.1:8050**

---

## 🎯 Using the Application

### Available Pages:

1. **🔮 Price Prediction** (`/`)
   - Select cryptocurrency
   - Choose prediction days (1-30)
   - Click "Generate Prediction"
   - View ML-powered price forecasts

2. **📊 Crypto Listings** (`/listings`)
   - Browse top cryptocurrencies
   - Real-time market data
   - Interactive charts and analytics

3. **💱 Currency Converter** (`/converter`)
   - Convert between 15+ cryptocurrencies
   - Real-time exchange rates
   - Historical conversion charts

4. **📰 Crypto News** (`/news`)
   - Latest cryptocurrency news
   - Aggregated from multiple sources
   - Stay updated with market trends

---

## 🔧 Troubleshooting

### Problem: "ModuleNotFoundError"
**Solution:**
```bash
pip install -r requirements.txt
```

### Problem: "Port 8050 already in use"
**Solution:**
```bash
# Find the process using port 8050
netstat -ano | findstr :8050

# Kill the process (replace PID with actual number)
taskkill /PID <PID> /F
```

### Problem: API errors for news or data
**Solution:**
- Check internet connection
- Optional: Create `.env` file with API keys
  ```
  NEWS_API_KEY=your_key_here
  COINGECKO_API_KEY=your_key_here
  ```

### Problem: Models not found
**Solution:**
The models will be auto-trained on first use. Just click "Generate Prediction" and wait for training to complete.

---

## 📂 Project Structure

```
python practice/
├── app.py                    # Main application (START HERE)
├── run.py                    # Alternative startup script
├── requirements.txt          # Dependencies list
├── README.md                 # Project documentation
├── SETUP_GUIDE.md           # This file
│
├── pages/                    # Application pages
│   ├── price_prediction.py  # ML price prediction
│   ├── crypto_listings.py   # Market listings
│   ├── converter.py         # Currency converter
│   └── news_feed.py         # News aggregation
│
├── data/                     # Data processing
│   └── processor.py         # Data fetching and processing
│
├── models/                   # Trained ML models
│   ├── BTC_USD_model.pkl    # Bitcoin model
│   ├── ETH_USD_model.pkl    # Ethereum model
│   └── SOL_USD_model.pkl    # Solana model
│
└── datasets/                 # Historical data (optional)
    ├── BTC_USD_1y.csv
    ├── ETH_USD_1y.csv
    └── ... (24 CSV files)
```

---

## 🚀 Alternative Run Methods

### Method 1: Using `app.py` (Simple)
```bash
python app.py
```

### Method 2: Using `run.py` (Auto-setup)
```bash
python run.py
```
This auto-installs dependencies and creates directories.

### Method 3: Development Mode (with auto-reload)
```bash
# In app.py, change line 85 to:
app.run(debug=True, host='127.0.0.1', port=8050)

python app.py
```

### Method 4: Run in Background
```bash
# Windows PowerShell
Start-Process python app.py

# Or use screen/tmux on Linux/Mac
```

---

## 🌐 Deployment to Production

### Local Network Access:
```bash
# In app.py, change line 85 to:
app.run(debug=False, host='0.0.0.0', port=8050)
```

Then access from other devices on same network:
- Desktop: http://localhost:8050
- Mobile: http://192.168.1.X:8050 (your computer's IP)

### Production Deployment Options:

**1. Heroku:**
```bash
# Create Procfile
echo "web: gunicorn app:server" > Procfile

# Deploy
git init
heroku create crypto-hub-app
git push heroku main
```

**2. PythonAnywhere:**
- Upload files via dashboard
- Create web app
- Point to app.py

**3. AWS/DigitalOcean:**
- Use Gunicorn + Nginx
- Set up reverse proxy

---

## ✅ Quick Checklist

Before running:
- [ ] Python 3.8+ installed
- [ ] Dependencies installed (`pip install -r requirements.txt`)
- [ ] In correct directory
- [ ] Internet connection active

After running:
- [ ] Browser opens to http://127.0.0.1:8050
- [ ] All 4 pages load correctly
- [ ] Price predictions generate successfully

---

## 🆘 Getting Help

### Common Commands:
```bash
# Check Python version
python --version

# List installed packages
pip list

# Update a package
pip install --upgrade package_name

# Check if port is in use
netstat -ano | findstr :8050

# View application logs
# Check terminal output when running app.py
```

### Need More Help?
1. Check the error message in terminal
2. Verify all dependencies are installed
3. Ensure you're in the correct directory
4. Check internet connection for API calls

---

## 📊 System Requirements

### Minimum:
- **Python:** 3.8+
- **RAM:** 2GB
- **Disk Space:** 500MB
- **Internet:** Required (for data fetching)

### Recommended:
- **Python:** 3.10+
- **RAM:** 4GB+
- **Disk Space:** 1GB
- **Internet:** High speed

---

## 🎉 You're All Set!

Once running, you can:
- ✅ Generate price predictions
- ✅ Browse crypto market data
- ✅ Convert currencies
- ✅ Read crypto news
- ✅ Analyze historical trends

Enjoy using Crypto Hub! 🚀









