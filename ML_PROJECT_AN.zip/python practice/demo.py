#!/usr/bin/env python3
"""
Crypto Hub Demo Script
This script demonstrates the functionality of the Crypto Hub application
"""

import os
import sys
import time
from datetime import datetime

# Add the project root to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

def demo_price_prediction():
    """Demo the price prediction functionality"""
    print("🔮 Testing Price Prediction...")
    
    try:
        from pages.price_prediction import CryptoPredictor
        
        predictor = CryptoPredictor()
        
        # Test data fetching
        print("📊 Fetching Bitcoin data...")
        data = predictor.fetch_crypto_data('BTC-USD', period='3mo')
        
        if data is not None and not data.empty:
            print(f"✅ Successfully fetched {len(data)} days of Bitcoin data")
            print(f"   Latest price: ${data['Close'].iloc[-1]:,.2f}")
            
            # Test technical indicators
            print("📈 Calculating technical indicators...")
            df_with_indicators = predictor.calculate_technical_indicators(data)
            print(f"✅ Calculated indicators for {len(df_with_indicators)} days")
            
            # Test model training
            print("🤖 Training ML model...")
            success, message = predictor.train_model('BTC-USD')
            print(f"✅ {message}")
            
            # Test prediction
            print("🔮 Generating price predictions...")
            predictions, pred_message = predictor.predict_price('BTC-USD', days_ahead=7)
            if predictions:
                print(f"✅ {pred_message}")
                print(f"   Predicted prices for next 7 days: {[f'${p:.2f}' for p in predictions]}")
            else:
                print(f"❌ {pred_message}")
        else:
            print("❌ Failed to fetch Bitcoin data")
            
    except Exception as e:
        print(f"❌ Error in price prediction demo: {e}")

def demo_crypto_listings():
    """Demo the crypto listings functionality"""
    print("\n📊 Testing Crypto Listings...")
    
    try:
        from pages.crypto_listings import CryptoDataFetcher
        
        fetcher = CryptoDataFetcher()
        
        # Test fetching top cryptos
        print("📈 Fetching top cryptocurrencies...")
        cryptos = fetcher.get_top_cryptos(limit=10)
        
        if cryptos:
            print(f"✅ Successfully fetched {len(cryptos)} cryptocurrencies")
            for crypto in cryptos[:3]:  # Show first 3
                name = crypto.get('name', 'Unknown')
                price = crypto.get('current_price', 0)
                change = crypto.get('price_change_percentage_24h', 0)
                print(f"   {name}: ${price:,.2f} ({change:+.2f}%)")
        else:
            print("❌ Failed to fetch cryptocurrency data")
            
    except Exception as e:
        print(f"❌ Error in crypto listings demo: {e}")

def demo_converter():
    """Demo the currency converter functionality"""
    print("\n💱 Testing Currency Converter...")
    
    try:
        from pages.converter import CryptoConverter
        
        converter = CryptoConverter()
        
        # Test conversion
        print("🔄 Converting 1 Bitcoin to Ethereum...")
        converted_amount, message = converter.convert_crypto('bitcoin', 'ethereum', 1)
        
        if converted_amount is not None:
            print(f"✅ {message}")
            print(f"   1 Bitcoin = {converted_amount:.6f} Ethereum")
        else:
            print(f"❌ {message}")
            
        # Test price fetching
        print("💰 Fetching current prices...")
        btc_price = converter.get_crypto_price('bitcoin')
        eth_price = converter.get_crypto_price('ethereum')
        
        if btc_price and eth_price:
            btc_usd = btc_price.get('bitcoin', {}).get('usd', 0)
            eth_usd = eth_price.get('ethereum', {}).get('usd', 0)
            print(f"✅ Bitcoin: ${btc_usd:,.2f}")
            print(f"✅ Ethereum: ${eth_usd:,.2f}")
        else:
            print("❌ Failed to fetch price data")
            
    except Exception as e:
        print(f"❌ Error in converter demo: {e}")

def demo_news_feed():
    """Demo the news feed functionality"""
    print("\n📰 Testing News Feed...")
    
    try:
        from pages.news_feed import CryptoNewsFetcher
        
        news_fetcher = CryptoNewsFetcher()
        
        # Test news fetching
        print("📰 Fetching crypto news...")
        articles = news_fetcher.get_all_crypto_news()
        
        if articles:
            print(f"✅ Successfully fetched {len(articles)} news articles")
            for article in articles[:3]:  # Show first 3
                title = article.get('title', 'No title')[:50]
                source = article.get('source', 'Unknown')
                print(f"   {title}... ({source})")
        else:
            print("❌ Failed to fetch news articles")
            
    except Exception as e:
        print(f"❌ Error in news feed demo: {e}")

def demo_data_processing():
    """Demo the data processing functionality"""
    print("\n🔧 Testing Data Processing...")
    
    try:
        from data.processor import CryptoDataProcessor
        
        processor = CryptoDataProcessor()
        
        # Test data fetching
        print("📊 Fetching historical data...")
        data = processor.fetch_historical_data('BTC-USD', period='1mo')
        
        if data is not None and not data.empty:
            print(f"✅ Successfully fetched {len(data)} days of data")
            
            # Test technical indicators
            print("📈 Calculating technical indicators...")
            df_with_indicators = processor.calculate_technical_indicators(data)
            print(f"✅ Calculated indicators for {len(df_with_indicators)} days")
            
            # Test trend detection
            print("🔍 Detecting trends...")
            trends = processor.detect_trends(data)
            if trends:
                print("✅ Trend analysis completed:")
                for trend_type, trend_value in trends.items():
                    print(f"   {trend_type}: {trend_value}")
            
            # Test volatility calculation
            print("📊 Calculating volatility...")
            volatility = processor.calculate_volatility(data)
            if volatility:
                print(f"✅ Current volatility: {volatility['current_volatility']:.2%}")
        else:
            print("❌ Failed to fetch historical data")
            
    except Exception as e:
        print(f"❌ Error in data processing demo: {e}")

def main():
    """Run all demos"""
    print("🚀 Crypto Hub - Demo Script")
    print("=" * 50)
    print(f"📅 Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    # Run all demos
    demo_price_prediction()
    demo_crypto_listings()
    demo_converter()
    demo_news_feed()
    demo_data_processing()
    
    print("\n" + "=" * 50)
    print("✅ Demo completed!")
    print("\n📋 Next steps:")
    print("1. Install dependencies: pip install -r requirements.txt")
    print("2. Set up API keys in .env file (optional)")
    print("3. Run the application: python app.py")
    print("4. Open browser to: http://localhost:8050")

if __name__ == "__main__":
    main()



