#!/usr/bin/env python3
"""
Crypto Hub - Machine Learning Price Prediction Platform
Startup script to run the application
"""

import os
import sys
import subprocess
from pathlib import Path

def check_python_version():
    """Check if Python version is compatible"""
    if sys.version_info < (3, 8):
        print("❌ Python 3.8 or higher is required")
        print(f"Current version: {sys.version}")
        return False
    print(f"✅ Python version: {sys.version.split()[0]}")
    return True

def install_dependencies():
    """Install required dependencies"""
    print("📦 Installing dependencies...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("✅ Dependencies installed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to install dependencies: {e}")
        return False

def create_directories():
    """Create necessary directories"""
    directories = ["models", "data", "logs"]
    for directory in directories:
        Path(directory).mkdir(exist_ok=True)
        print(f"✅ Created directory: {directory}")

def check_env_file():
    """Check if environment file exists"""
    if not os.path.exists(".env"):
        print("⚠️  .env file not found")
        print("📝 Please copy env_example.txt to .env and add your API keys")
        print("   - NEWS_API_KEY: Get from https://newsapi.org/")
        print("   - COINGECKO_API_KEY: Optional, free tier available")
        return False
    print("✅ .env file found")
    return True

def run_application():
    """Run the main application"""
    print("🚀 Starting Crypto Hub...")
    try:
        subprocess.run([sys.executable, "app.py"])
    except KeyboardInterrupt:
        print("\n👋 Application stopped by user")
    except Exception as e:
        print(f"❌ Error running application: {e}")

def main():
    """Main startup function"""
    print("🚀 Crypto Hub - Machine Learning Price Prediction Platform")
    print("=" * 60)
    
    # Check Python version
    if not check_python_version():
        sys.exit(1)
    
    # Create directories
    create_directories()
    
    # Install dependencies
    if not install_dependencies():
        print("⚠️  Continuing without installing dependencies...")
    
    # Check environment file
    env_exists = check_env_file()
    if not env_exists:
        print("\n📋 Setup Instructions:")
        print("1. Copy env_example.txt to .env")
        print("2. Add your API keys to .env file")
        print("3. Run this script again")
        print("\n🔗 Get API keys from:")
        print("   - NewsAPI: https://newsapi.org/")
        print("   - CoinGecko: https://www.coingecko.com/en/api")
        
        response = input("\nDo you want to continue without API keys? (y/n): ")
        if response.lower() != 'y':
            sys.exit(0)
    
    # Run application
    run_application()

if __name__ == "__main__":
    main()



