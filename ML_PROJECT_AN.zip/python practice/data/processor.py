import pandas as pd
import numpy as np
import yfinance as yf
from datetime import datetime, timedelta
import requests
import time

class CryptoDataProcessor:
    """Process and analyze cryptocurrency data"""
    
    def __init__(self):
        self.cache = {}
        self.cache_timeout = 300  # 5 minutes
    
    def fetch_historical_data(self, symbol, period='1y'):
        """Fetch historical cryptocurrency data"""
        cache_key = f"historical_{symbol}_{period}"
        
        if self._is_cache_valid(cache_key):
            return self.cache[cache_key]['data']
        
        try:
            # Remove -USD suffix if it already exists
            if symbol.endswith('-USD'):
                clean_symbol = symbol
            else:
                clean_symbol = f"{symbol}-USD"
            
            ticker = yf.Ticker(clean_symbol)
            data = ticker.history(period=period)
            
            if data.empty:
                return None
            
            # Cache the data
            self.cache[cache_key] = {
                'data': data,
                'timestamp': time.time()
            }
            
            return data
            
        except Exception as e:
            print(f"Error fetching historical data for {symbol}: {e}")
            return None
    
    def calculate_technical_indicators(self, data):
        """Calculate technical indicators for the dataset"""
        df = data.copy()
        
        # Moving averages
        df['MA_7'] = df['Close'].rolling(window=7).mean()
        df['MA_30'] = df['Close'].rolling(window=30).mean()
        df['MA_50'] = df['Close'].rolling(window=50).mean()
        
        # Exponential moving averages
        df['EMA_12'] = df['Close'].ewm(span=12).mean()
        df['EMA_26'] = df['Close'].ewm(span=26).mean()
        
        # RSI calculation
        delta = df['Close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        rs = gain / loss
        df['RSI'] = 100 - (100 / (1 + rs))
        
        # MACD calculation
        df['MACD'] = df['EMA_12'] - df['EMA_26']
        df['MACD_Signal'] = df['MACD'].ewm(span=9).mean()
        df['MACD_Histogram'] = df['MACD'] - df['MACD_Signal']
        
        # Bollinger Bands
        df['BB_Middle'] = df['Close'].rolling(window=20).mean()
        bb_std = df['Close'].rolling(window=20).std()
        df['BB_Upper'] = df['BB_Middle'] + (bb_std * 2)
        df['BB_Lower'] = df['BB_Middle'] - (bb_std * 2)
        
        # Volume indicators
        df['Volume_MA'] = df['Volume'].rolling(window=20).mean()
        df['Volume_Ratio'] = df['Volume'] / df['Volume_MA']
        
        # Price change indicators
        df['Price_Change_1d'] = df['Close'].pct_change(1)
        df['Price_Change_7d'] = df['Close'].pct_change(7)
        df['Price_Change_30d'] = df['Close'].pct_change(30)
        
        return df.dropna()
    
    def get_market_summary(self, symbols=['BTC-USD', 'ETH-USD', 'BNB-USD']):
        """Get market summary for multiple cryptocurrencies"""
        summary = []
        
        for symbol in symbols:
            data = self.fetch_historical_data(symbol, period='30d')
            if data is not None and not data.empty:
                current_price = data['Close'].iloc[-1]
                price_24h_ago = data['Close'].iloc[-2] if len(data) > 1 else current_price
                change_24h = ((current_price - price_24h_ago) / price_24h_ago) * 100
                
                volume_24h = data['Volume'].iloc[-1]
                
                summary.append({
                    'symbol': symbol,
                    'price': current_price,
                    'change_24h': change_24h,
                    'volume_24h': volume_24h,
                    'market_cap': current_price * 21000000  # Approximate for BTC
                })
        
        return summary
    
    def detect_trends(self, data):
        """Detect trends in cryptocurrency data"""
        if data is None or data.empty:
            return None
        
        df = self.calculate_technical_indicators(data)
        
        # Trend analysis
        current_price = df['Close'].iloc[-1]
        ma_7 = df['MA_7'].iloc[-1]
        ma_30 = df['MA_30'].iloc[-1]
        rsi = df['RSI'].iloc[-1]
        
        trends = {
            'short_term': 'Bullish' if current_price > ma_7 else 'Bearish',
            'medium_term': 'Bullish' if current_price > ma_30 else 'Bearish',
            'rsi_signal': 'Overbought' if rsi > 70 else 'Oversold' if rsi < 30 else 'Neutral',
            'macd_signal': 'Bullish' if df['MACD'].iloc[-1] > df['MACD_Signal'].iloc[-1] else 'Bearish'
        }
        
        return trends
    
    def calculate_volatility(self, data, window=30):
        """Calculate price volatility"""
        if data is None or data.empty:
            return None
        
        returns = data['Close'].pct_change().dropna()
        volatility = returns.rolling(window=window).std() * np.sqrt(365)  # Annualized
        
        return {
            'current_volatility': volatility.iloc[-1] if not volatility.empty else 0,
            'average_volatility': volatility.mean(),
            'max_volatility': volatility.max(),
            'min_volatility': volatility.min()
        }
    
    def _is_cache_valid(self, cache_key):
        """Check if cached data is still valid"""
        if cache_key not in self.cache:
            return False
        
        cache_time = self.cache[cache_key]['timestamp']
        return (time.time() - cache_time) < self.cache_timeout

# Initialize data processor
data_processor = CryptoDataProcessor()

