import os
import pandas as pd
import numpy as np
import yfinance as yf
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, r2_score
import joblib
import plotly.graph_objs as go
from plotly.subplots import make_subplots
import requests
from datetime import datetime, timedelta
import dash
from dash import dcc, html, Input, Output, State, callback
import dash_bootstrap_components as dbc

class CryptoPredictor:
    def __init__(self):
        self.model = None
        self.scaler = StandardScaler()
        self.feature_columns = ['Open', 'High', 'Low', 'Volume', 'MA_7', 'MA_30', 'RSI', 'MACD']
        
    def fetch_crypto_data(self, symbol, period='1y'):
        """Fetch cryptocurrency data from Yahoo Finance"""
        try:
            # Remove -USD suffix if it already exists
            if symbol.endswith('-USD'):
                clean_symbol = symbol
            else:
                clean_symbol = f"{symbol}-USD"
            
            ticker = yf.Ticker(clean_symbol)
            data = ticker.history(period=period)
            return data
        except Exception as e:
            print(f"Error fetching data for {symbol}: {e}")
            return None
    
    def calculate_technical_indicators(self, data):
        """Calculate technical indicators for the dataset"""
        df = data.copy()
        
        # Moving averages
        df['MA_7'] = df['Close'].rolling(window=7).mean()
        df['MA_30'] = df['Close'].rolling(window=30).mean()
        
        # RSI calculation
        delta = df['Close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        rs = gain / loss
        df['RSI'] = 100 - (100 / (1 + rs))
        
        # MACD calculation
        exp1 = df['Close'].ewm(span=12).mean()
        exp2 = df['Close'].ewm(span=26).mean()
        df['MACD'] = exp1 - exp2
        
        return df.dropna()
    
    def prepare_features(self, data):
        """Prepare features for machine learning"""
        df = self.calculate_technical_indicators(data)
        
        # Select features
        features = df[self.feature_columns].values
        target = df['Close'].values
        
        return features, target, df
    
    def train_model(self, symbol='BTC-USD'):
        """Train the machine learning model"""
        print(f"Training model for {symbol}...")
        
        # Fetch data
        data = self.fetch_crypto_data(symbol)
        if data is None or len(data) < 100:
            return False, "Insufficient data for training"
        
        # Prepare features
        X, y, df = self.prepare_features(data)
        
        if len(X) < 50:
            return False, "Insufficient data after preprocessing"
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, shuffle=False
        )
        
        # Scale features
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        # Train model
        self.model = RandomForestRegressor(
            n_estimators=100,
            random_state=42,
            max_depth=10,
            min_samples_split=5
        )
        
        self.model.fit(X_train_scaled, y_train)
        
        # Evaluate model
        y_pred = self.model.predict(X_test_scaled)
        mse = mean_squared_error(y_test, y_pred)
        r2 = r2_score(y_test, y_pred)
        
        # Save model
        model_path = f"models/{symbol.replace('-', '_')}_model.pkl"
        os.makedirs("models", exist_ok=True)
        joblib.dump({
            'model': self.model,
            'scaler': self.scaler,
            'feature_columns': self.feature_columns
        }, model_path)
        
        return True, f"Model trained successfully. R² Score: {r2:.4f}, MSE: {mse:.2f}"
    
    def load_model(self, symbol):
        """Load a pre-trained model"""
        model_path = f"models/{symbol.replace('-', '_')}_model.pkl"
        if os.path.exists(model_path):
            model_data = joblib.load(model_path)
            self.model = model_data['model']
            self.scaler = model_data['scaler']
            self.feature_columns = model_data['feature_columns']
            return True
        return False
    
    def predict_price(self, symbol, days_ahead=7):
        """Predict future prices"""
        if not self.load_model(symbol):
            success, message = self.train_model(symbol)
            if not success:
                return None, message
        
        # Fetch recent data
        data = self.fetch_crypto_data(symbol, period='3mo')
        if data is None:
            return None, "Could not fetch recent data"
        
        # Prepare features
        X, y, df = self.prepare_features(data)
        if len(X) == 0:
            return None, "Could not prepare features"
        
        # Get last known features
        last_features = X[-1:].copy()
        predictions = []
        
        for day in range(days_ahead):
            # Scale features
            features_scaled = self.scaler.transform(last_features)
            
            # Predict next day
            pred_price = self.model.predict(features_scaled)[0]
            predictions.append(pred_price)
            
            # Update features for next prediction (simplified)
            # In a real implementation, you'd update all technical indicators
            last_features[0][0] = pred_price  # Update Open price
        
        return predictions, "Predictions generated successfully"

# Initialize predictor
predictor = CryptoPredictor()

# Layout for price prediction page
layout = dbc.Container([
    dbc.Row([
        dbc.Col([
            html.H2("🔮 Crypto Price Prediction", className="text-center mb-4 gradient-text"),
            html.P("Predict future cryptocurrency prices using machine learning", 
                   className="text-center text-muted mb-4"),
        ], width=12)
    ], className="fade-in"),
    
    dbc.Row([
        dbc.Col([
            dbc.Card([
                dbc.CardBody([
                    html.H5("Select Cryptocurrency", className="card-title"),
                    dcc.Dropdown(
                        id='crypto-selector',
                        options=[
                            {'label': 'Bitcoin (BTC)', 'value': 'BTC-USD'},
                            {'label': 'Ethereum (ETH)', 'value': 'ETH-USD'},
                            {'label': 'Binance Coin (BNB)', 'value': 'BNB-USD'},
                            {'label': 'Cardano (ADA)', 'value': 'ADA-USD'},
                            {'label': 'Solana (SOL)', 'value': 'SOL-USD'},
                            {'label': 'Polkadot (DOT)', 'value': 'DOT-USD'},
                            {'label': 'Chainlink (LINK)', 'value': 'LINK-USD'},
                            {'label': 'Litecoin (LTC)', 'value': 'LTC-USD'},
                        ],
                        value='BTC-USD',
                        className="mb-3"
                    ),
                    
                    html.Label("Days to Predict:"),
                    dcc.Slider(
                        id='days-slider',
                        min=1,
                        max=30,
                        step=1,
                        value=7,
                        marks={i: str(i) for i in range(1, 31, 5)},
                        className="mb-3"
                    ),
                    
                    dbc.Button(
                        "🚀 Generate Prediction",
                        id='predict-button',
                        color="primary",
                        className="w-100 hover-lift"
                    )
                ])
            ])
        ], width=4),
        
        dbc.Col([
            dbc.Card([
                dbc.CardBody([
                    html.H5("Price Prediction Chart", className="card-title"),
                    dcc.Graph(id='prediction-chart'),
                    html.Div(id='prediction-status', className="mt-3")
                ])
            ])
        ], width=8)
    ], className="mb-4"),
    
    dbc.Row([
        dbc.Col([
            dbc.Card([
                dbc.CardBody([
                    html.H5("Model Performance", className="card-title"),
                    html.Div(id='model-performance')
                ])
            ])
        ], width=12)
    ])
])

# Callbacks
@callback(
    [Output('prediction-chart', 'figure'),
     Output('prediction-status', 'children')],
    [Input('predict-button', 'n_clicks')],
    [State('crypto-selector', 'value'),
     State('days-slider', 'value')]
)
def update_prediction(n_clicks, crypto_symbol, days_ahead):
    if n_clicks is None:
        return go.Figure(), ""
    
    # Fetch historical data
    data = predictor.fetch_crypto_data(crypto_symbol, period='6mo')
    if data is None:
        return go.Figure(), dbc.Alert("Error fetching data", color="danger")
    
    # Generate predictions
    predictions, message = predictor.predict_price(crypto_symbol, days_ahead)
    
    if predictions is None:
        return go.Figure(), dbc.Alert(message, color="danger")
    
    # Create chart
    fig = make_subplots(rows=2, cols=1, 
                       subplot_titles=('Price History & Prediction', 'Volume'),
                       vertical_spacing=0.1)
    
    # Historical data
    fig.add_trace(
        go.Scatter(x=data.index, y=data['Close'], 
                  name='Historical Price', line=dict(color='blue')),
        row=1, col=1
    )
    
    # Predictions
    future_dates = pd.date_range(start=data.index[-1], periods=days_ahead+1, freq='D')[1:]
    fig.add_trace(
        go.Scatter(x=future_dates, y=predictions, 
                  name='Predicted Price', line=dict(color='red', dash='dash')),
        row=1, col=1
    )
    
    # Volume
    fig.add_trace(
        go.Bar(x=data.index, y=data['Volume'], 
               name='Volume', marker_color='lightblue'),
        row=2, col=1
    )
    
    fig.update_layout(height=600, showlegend=True)
    fig.update_xaxes(title_text="Date", row=2, col=1)
    fig.update_yaxes(title_text="Price (USD)", row=1, col=1)
    fig.update_yaxes(title_text="Volume", row=2, col=1)
    
    status = dbc.Alert(f"✅ {message}", color="success")
    
    return fig, status

