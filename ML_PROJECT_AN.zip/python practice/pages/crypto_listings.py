import requests
import pandas as pd
import plotly.graph_objs as go
from plotly.subplots import make_subplots
import dash
from dash import dcc, html, Input, Output, callback
import dash_bootstrap_components as dbc
from datetime import datetime
import time

class CryptoDataFetcher:
    def __init__(self):
        self.base_url = "https://api.coingecko.com/api/v3"
        self.cache = {}
        self.cache_timeout = 300  # 5 minutes
        self.last_error = None
        
    def get_top_cryptos(self, limit=50):
        """Fetch top cryptocurrencies by market cap"""
        cache_key = f"top_cryptos_{limit}"
        
        if self._is_cache_valid(cache_key):
            return self.cache[cache_key]['data']
        
        try:
            url = f"{self.base_url}/coins/markets"
            params = {
                'vs_currency': 'usd',
                'order': 'market_cap_desc',
                'per_page': limit,
                'page': 1,
                'sparkline': True,
                'price_change_percentage': '1h,24h,7d'
            }
            
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            
            # Cache the data
            self.cache[cache_key] = {
                'data': data,
                'timestamp': time.time()
            }
            self.last_error = None
            
            return data
            
        except Exception as e:
            self.last_error = str(e)
            print(f"Error fetching crypto data: {e}")
            return []
    
    def get_crypto_details(self, coin_id):
        """Get detailed information about a specific cryptocurrency"""
        cache_key = f"crypto_details_{coin_id}"
        
        if self._is_cache_valid(cache_key):
            return self.cache[cache_key]['data']
        
        try:
            url = f"{self.base_url}/coins/{coin_id}"
            params = {
                'localization': False,
                'tickers': False,
                'market_data': True,
                'community_data': False,
                'developer_data': False,
                'sparkline': True
            }
            
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            
            # Cache the data
            self.cache[cache_key] = {
                'data': data,
                'timestamp': time.time()
            }
            self.last_error = None
            
            return data
            
        except Exception as e:
            self.last_error = str(e)
            print(f"Error fetching crypto details: {e}")
            return None
    
    def _is_cache_valid(self, cache_key):
        """Check if cached data is still valid"""
        if cache_key not in self.cache:
            return False
        
        cache_time = self.cache[cache_key]['timestamp']
        return (time.time() - cache_time) < self.cache_timeout

# Initialize data fetcher
crypto_fetcher = CryptoDataFetcher()

# Layout for crypto listings page
layout = dbc.Container([
    dbc.Row([
        dbc.Col([
            html.H2("📊 Cryptocurrency Market Overview", className="text-center mb-4 gradient-text"),
            html.P("Real-time cryptocurrency prices and market data", 
                   className="text-center text-muted mb-4"),
        ], width=12)
    ], className="fade-in"),
    
    dbc.Row([
        dbc.Col([
            dbc.Card([
                dbc.CardBody([
                    html.H5("Market Controls", className="card-title"),
                    
                    dbc.Row([
                        dbc.Col([
                            html.Label("Number of Cryptocurrencies:"),
                            dcc.Dropdown(
                                id='crypto-limit',
                                options=[
                                    {'label': 'Top 25', 'value': 25},
                                    {'label': 'Top 50', 'value': 50},
                                    {'label': 'Top 100', 'value': 100},
                                ],
                                value=50,
                                className="mb-3"
                            )
                        ], width=6),
                        
                        dbc.Col([
                            html.Label("Sort By:"),
                            dcc.Dropdown(
                                id='sort-by',
                                options=[
                                    {'label': 'Market Cap', 'value': 'market_cap'},
                                    {'label': 'Price Change (24h)', 'value': 'price_change_percentage_24h'},
                                    {'label': 'Volume', 'value': 'total_volume'},
                                    {'label': 'Price', 'value': 'current_price'},
                                ],
                                value='market_cap',
                                className="mb-3"
                            )
                        ], width=6)
                    ]),
                    
                    dbc.Button(
                        "🔄 Refresh Data",
                        id='refresh-button',
                        color="primary",
                        className="w-100 hover-lift"
                    )
                ])
            ])
        ], width=3),
        
        dbc.Col([
            dbc.Card([
                dbc.CardBody([
                    html.H5("Cryptocurrency Table", className="card-title"),
                    html.Div(id='crypto-table')
                ])
            ])
        ], width=9)
    ], className="mb-4"),
    
    dbc.Row([
        dbc.Col([
            dbc.Card([
                dbc.CardBody([
                    html.H5("Market Overview Chart", className="card-title"),
                    dcc.Graph(id='market-chart')
                ])
            ])
        ], width=12)
    ]),
    
    dbc.Row([
        dbc.Col([
            dbc.Card([
                dbc.CardBody([
                    html.H5("Cryptocurrency Details", className="card-title"),
                    html.Div(id='crypto-details')
                ])
            ])
        ], width=12)
    ])
])

def create_crypto_table(crypto_data, sort_by='market_cap'):
    """Create a table showing cryptocurrency data"""
    if not crypto_data:
        error_msg = getattr(crypto_fetcher, 'last_error', 'Unknown error')
        return dbc.Alert(f"No data available. Error: {error_msg}", color="warning")
    
    # Sort data
    if sort_by == 'market_cap':
        crypto_data.sort(key=lambda x: (x.get('market_cap') or 0), reverse=True)
    elif sort_by == 'price_change_percentage_24h':
        crypto_data.sort(key=lambda x: (x.get('price_change_percentage_24h') or 0), reverse=True)
    elif sort_by == 'total_volume':
        crypto_data.sort(key=lambda x: (x.get('total_volume') or 0), reverse=True)
    elif sort_by == 'current_price':
        crypto_data.sort(key=lambda x: (x.get('current_price') or 0), reverse=True)
    
    # Create table rows
    rows = []
    for crypto in crypto_data[:50]:  # Limit to top 50 for performance
        # Format price
        price = crypto.get('current_price')
        if price is None: price = 0
        price_str = f"${price:,.2f}" if price > 1 else f"${price:.6f}"
        
        # Format market cap
        market_cap = crypto.get('market_cap')
        if market_cap is None: market_cap = 0
        market_cap_str = f"${market_cap:,.0f}" if market_cap > 0 else "N/A"
        
        # Format volume
        volume = crypto.get('total_volume')
        if volume is None: volume = 0
        volume_str = f"${volume:,.0f}" if volume > 0 else "N/A"
        
        # Price change colors
        change_24h = crypto.get('price_change_percentage_24h')
        if change_24h is None: change_24h = 0
        change_color = "success" if change_24h >= 0 else "danger"
        
        # Format circulating supply
        supply = crypto.get('circulating_supply')
        if supply is None: supply = 0
        supply_str = f"{supply:,.0f}" if supply > 0 else "N/A"
        
        rows.append(
            html.Tr([
                html.Td([
                    html.Img(
                        src=crypto.get('image', ''),
                        style={'width': '30px', 'height': '30px', 'vertical-align': 'middle', 'margin-right': '8px'}
                    ),
                    html.Strong(crypto.get('name', 'Unknown')),
                    html.Br(),
                    html.Small(crypto.get('symbol', '').upper(), className="text-muted")
                ], style={'vertical-align': 'middle'}),
                
                html.Td([
                    html.Strong(price_str),
                    html.Br(),
                    html.Span(
                        f"{change_24h:+.2f}%",
                        className=f"text-{change_color}"
                    )
                ], style={'vertical-align': 'middle'}),
                
                html.Td([
                    html.Span(market_cap_str),
                    html.Br(),
                    html.Small(f"#{crypto.get('market_cap_rank', 'N/A')}", className="text-muted")
                ], style={'vertical-align': 'middle'}),
                
                html.Td([
                    html.Span(volume_str)
                ], style={'vertical-align': 'middle'}),
                
                html.Td([
                    html.Span(supply_str)
                ], style={'vertical-align': 'middle'}),
                
                html.Td([
                    dbc.Button(
                        "Details",
                        size="sm",
                        color="outline-primary",
                        id={'type': 'details-btn', 'index': crypto.get('id', '')},
                        className="w-100"
                    )
                ], style={'vertical-align': 'middle', 'text-align': 'center'})
            ], className="align-middle")
        )
    
    table_header = html.Thead([
        html.Tr([
            html.Th("Cryptocurrency", style={'width': '25%'}),
            html.Th("Price", style={'width': '20%'}),
            html.Th("Market Cap", style={'width': '18%'}),
            html.Th("Volume (24h)", style={'width': '18%'}),
            html.Th("Supply", style={'width': '10%'}),
            html.Th("Action", style={'width': '9%', 'text-align': 'center'})
        ], className="table-light")
    ])
    
    table_body = html.Tbody(rows)
    
    return dbc.Table([
        table_header,
        table_body
    ], bordered=True, hover=True, responsive=True, striped=True, className="table align-middle")

def create_market_chart(crypto_data):
    """Create a market overview chart"""
    if not crypto_data:
        return go.Figure()
    
    # Prepare data for chart
    top_10 = crypto_data[:10]
    
    fig = make_subplots(
        rows=2, cols=2,
        subplot_titles=('Market Cap Distribution', 'Price Changes (24h)', 
                       'Volume vs Market Cap', 'Top Performers'),
        specs=[[{"type": "pie"}, {"type": "bar"}],
               [{"type": "scatter"}, {"type": "bar"}]]
    )
    
    # Market cap pie chart
    names = [crypto.get('name', 'Unknown') for crypto in top_10]
    market_caps = [(crypto.get('market_cap') or 0) for crypto in top_10]
    
    fig.add_trace(
        go.Pie(labels=names, values=market_caps, name="Market Cap"),
        row=1, col=1
    )
    
    # Price changes bar chart
    symbols = [crypto.get('symbol', '').upper() for crypto in top_10]
    changes = [(crypto.get('price_change_percentage_24h') or 0) for crypto in top_10]
    colors = ['green' if x >= 0 else 'red' for x in changes]
    
    fig.add_trace(
        go.Bar(x=symbols, y=changes, marker_color=colors, name="24h Change"),
        row=1, col=2
    )
    
    # Volume vs Market Cap scatter
    volumes = [(crypto.get('total_volume') or 0) for crypto in top_10]
    
    fig.add_trace(
        go.Scatter(x=market_caps, y=volumes, mode='markers+text',
                  text=symbols, textposition="top center",
                  marker=dict(size=10), name="Volume vs Market Cap"),
        row=2, col=1
    )
    
    # Top performers
    top_performers = sorted(top_10, key=lambda x: (x.get('price_change_percentage_24h') or 0), reverse=True)[:5]
    performer_names = [crypto.get('symbol', '').upper() for crypto in top_performers]
    performer_changes = [(crypto.get('price_change_percentage_24h') or 0) for crypto in top_performers]
    
    fig.add_trace(
        go.Bar(x=performer_names, y=performer_changes, 
               marker_color='lightgreen', name="Top Performers"),
        row=2, col=2
    )
    
    fig.update_layout(height=800, showlegend=False)
    
    return fig

# Callbacks
@callback(
    [Output('crypto-table', 'children'),
     Output('market-chart', 'figure')],
    [Input('refresh-button', 'n_clicks'),
     Input('crypto-limit', 'value'),
     Input('sort-by', 'value')]
)
def update_crypto_data(n_clicks, limit, sort_by):
    try:
        # Fetch crypto data
        crypto_data = crypto_fetcher.get_top_cryptos(limit)
        
        # Create table
        table = create_crypto_table(crypto_data, sort_by)
        
        # Create chart
        chart = create_market_chart(crypto_data)
        
        return table, chart
    except Exception as e:
        return dbc.Alert(f"Error updating data: {str(e)}", color="danger"), go.Figure()

@callback(
    Output('crypto-details', 'children'),
    Input({'type': 'details-btn', 'index': dash.ALL}, 'n_clicks'),
    prevent_initial_call=True
)
def show_crypto_details(n_clicks_list):
    if not n_clicks_list or all(n is None for n in n_clicks_list):
        return ""
    
    # Find which button was clicked
    ctx = dash.callback_context
    if not ctx.triggered or not ctx.triggered:
        return ""
    
    try:
        button_id_str = ctx.triggered[0]['prop_id']
        # Parse the button ID string to get the coin ID
        # Format: "{'type': 'details-btn', 'index': 'bitcoin'}.n_clicks"
        import ast
        button_id_dict = ast.literal_eval(button_id_str.split('.')[0])
        coin_id = button_id_dict.get('index')
        
        if not coin_id:
            return dbc.Alert("Could not identify cryptocurrency", color="warning")
        
        # Fetch detailed data
        details = crypto_fetcher.get_crypto_details(coin_id)
        
        if not details:
            error_msg = getattr(crypto_fetcher, 'last_error', 'Unknown error')
            return dbc.Alert(f"Could not fetch details. Error: {error_msg}", color="danger")
        
        market_data = details.get('market_data', {})
        
        # Get current price - handle both dict and direct value
        current_price = market_data.get('current_price', {})
        if isinstance(current_price, dict):
            price_usd = current_price.get('usd', 0)
        else:
            price_usd = current_price if current_price else 0
        
        # Get market cap - handle both dict and direct value
        market_cap = market_data.get('market_cap', {})
        if isinstance(market_cap, dict):
            cap_usd = market_cap.get('usd', 0)
        else:
            cap_usd = market_cap if market_cap else 0
        
        # Get volume - handle both dict and direct value
        volume = market_data.get('total_volume', {})
        if isinstance(volume, dict):
            volume_usd = volume.get('usd', 0)
        else:
            volume_usd = volume if volume else 0
        
        # Get ATH - handle both dict and direct value
        ath = market_data.get('ath', {})
        if isinstance(ath, dict):
            ath_usd = ath.get('usd', 0)
        else:
            ath_usd = ath if ath else 0
        
        # Get ATL - handle both dict and direct value
        atl = market_data.get('atl', {})
        if isinstance(atl, dict):
            atl_usd = atl.get('usd', 0)
        else:
            atl_usd = atl if atl else 0
        
        # Get price change and supply
        price_change_24h = market_data.get('price_change_percentage_24h', 0)
        circulating_supply = market_data.get('circulating_supply', 0)
        
        return dbc.Card([
            dbc.CardBody([
                html.H4(f"{details.get('name', 'Unknown')} ({details.get('symbol', '').upper()})"),
                
                dbc.Row([
                    dbc.Col([
                        html.H6("Current Price"),
                        html.H3(f"${price_usd:,.2f}")
                    ], width=3),
                    
                    dbc.Col([
                        html.H6("Market Cap"),
                        html.H3(f"${cap_usd:,.0f}")
                    ], width=3),
                    
                    dbc.Col([
                        html.H6("24h Change"),
                        html.H3([
                            f"{price_change_24h:+.2f}%"
                        ], className=f"text-{'success' if price_change_24h >= 0 else 'danger'}")
                    ], width=3),
                    
                    dbc.Col([
                        html.H6("Volume (24h)"),
                        html.H3(f"${volume_usd:,.0f}")
                    ], width=3)
                ]),
                
                html.Hr(),
                
                dbc.Row([
                    dbc.Col([
                        html.H6("All-Time High"),
                        html.P(f"${ath_usd:,.2f}")
                    ], width=4),
                    
                    dbc.Col([
                        html.H6("All-Time Low"),
                        html.P(f"${atl_usd:,.2f}")
                    ], width=4),
                    
                    dbc.Col([
                        html.H6("Circulating Supply"),
                        html.P(f"{circulating_supply:,.0f}")
                    ], width=4)
                ])
            ])
        ])
    except Exception as e:
        return dbc.Alert(f"Error loading details: {str(e)}", color="danger")
