import os
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
import joblib
import plotly.graph_objs as go
from plotly.subplots import make_subplots
from datetime import datetime, timedelta
import dash
from dash import dcc, html, Input, Output, State, callback
import dash_bootstrap_components as dbc
import base64
import io

class SalesForecaster:
    def __init__(self):
        self.model = None
        self.scaler = StandardScaler()
        self.feature_columns = ['day_of_week', 'day_of_month', 'month', 'quarter', 
                              'lag_1', 'lag_7', 'lag_30', 'rolling_mean_7', 
                              'rolling_mean_30', 'trend']
        
    def prepare_sales_data(self, df):
        """Prepare sales data with features for machine learning"""
        # Ensure we have a date column
        if 'date' in df.columns:
            df['date'] = pd.to_datetime(df['date'])
            df = df.sort_values('date')
        elif df.index.dtype == 'datetime64[ns]':
            df['date'] = df.index
        else:
            # Create date index if none exists
            df['date'] = pd.date_range(start='2020-01-01', periods=len(df), freq='D')
        
        # Ensure we have a sales column
        if 'sales' not in df.columns and 'value' not in df.columns:
            # Use first numeric column as sales
            numeric_cols = df.select_dtypes(include=[np.number]).columns
            if len(numeric_cols) > 0:
                df['sales'] = df[numeric_cols[0]]
            else:
                return None, None, None
        elif 'value' in df.columns:
            df['sales'] = df['value']
        
        df = df.set_index('date')
        df = df.sort_index()
        
        # Create time-based features
        df['day_of_week'] = df.index.dayofweek
        df['day_of_month'] = df.index.day
        df['month'] = df.index.month
        df['quarter'] = df.index.quarter
        df['year'] = df.index.year
        
        # Create lag features
        df['lag_1'] = df['sales'].shift(1)
        df['lag_7'] = df['sales'].shift(7)
        df['lag_30'] = df['sales'].shift(30)
        
        # Rolling statistics
        df['rolling_mean_7'] = df['sales'].rolling(window=7).mean()
        df['rolling_mean_30'] = df['sales'].rolling(window=30).mean()
        df['rolling_std_7'] = df['sales'].rolling(window=7).std()
        
        # Trend feature
        df['trend'] = range(len(df))
        
        # Remove rows with NaN values
        df = df.dropna()
        
        if len(df) < 50:
            return None, None, None
        
        # Select features
        features = df[self.feature_columns].values
        target = df['sales'].values
        
        return features, target, df
    
    def train_model(self, df):
        """Train the sales forecasting model"""
        print("Training sales forecasting model...")
        
        # Prepare features
        X, y, processed_df = self.prepare_sales_data(df)
        
        if X is None:
            return False, "Insufficient data for training. Need at least 50 data points."
        
        if len(X) < 50:
            return False, "Insufficient data after preprocessing"
        
        # Split data (use time-based split, not random)
        split_idx = int(len(X) * 0.8)
        X_train, X_test = X[:split_idx], X[split_idx:]
        y_train, y_test = y[:split_idx], y[split_idx:]
        
        # Scale features
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        # Train model
        self.model = RandomForestRegressor(
            n_estimators=100,
            random_state=42,
            max_depth=10,
            min_samples_split=5,
            n_jobs=-1
        )
        
        self.model.fit(X_train_scaled, y_train)
        
        # Evaluate model
        y_pred = self.model.predict(X_test_scaled)
        mse = mean_squared_error(y_test, y_pred)
        r2 = r2_score(y_test, y_pred)
        mae = mean_absolute_error(y_test, y_pred)
        
        # Save model
        model_path = "models/sales_forecast_model.pkl"
        os.makedirs("models", exist_ok=True)
        joblib.dump({
            'model': self.model,
            'scaler': self.scaler,
            'feature_columns': self.feature_columns
        }, model_path)
        
        metrics = {
            'r2_score': r2,
            'mse': mse,
            'mae': mae,
            'rmse': np.sqrt(mse)
        }
        
        return True, f"Model trained successfully. R² Score: {r2:.4f}, RMSE: {np.sqrt(mse):.2f}, MAE: {mae:.2f}", metrics
    
    def load_model(self):
        """Load a pre-trained model"""
        model_path = "models/sales_forecast_model.pkl"
        if os.path.exists(model_path):
            model_data = joblib.load(model_path)
            self.model = model_data['model']
            self.scaler = model_data['scaler']
            self.feature_columns = model_data['feature_columns']
            return True
        return False
    
    def forecast_sales(self, df, days_ahead=30):
        """Forecast future sales"""
        if not self.load_model():
            success, message, metrics = self.train_model(df)
            if not success:
                return None, message, None
        
        # Prepare features from historical data
        X, y, processed_df = self.prepare_sales_data(df)
        
        if X is None or len(X) == 0:
            return None, "Could not prepare features from data", None
        
        # Get the last known data point
        last_row = processed_df.iloc[-1:].copy()
        last_date = processed_df.index[-1]
        
        predictions = []
        prediction_dates = []
        
        # Create a copy of the last row for iterative prediction
        current_data = last_row.copy()
        
        for day in range(1, days_ahead + 1):
            # Prepare features for prediction
            future_date = last_date + timedelta(days=day)
            
            # Update time-based features
            features_dict = {
                'day_of_week': future_date.dayofweek,
                'day_of_month': future_date.day,
                'month': future_date.month,
                'quarter': future_date.quarter,
                'lag_1': current_data['sales'].iloc[0] if len(current_data) > 0 else last_row['sales'].iloc[0],
                'lag_7': processed_df['sales'].iloc[-7] if len(processed_df) >= 7 else last_row['sales'].iloc[0],
                'lag_30': processed_df['sales'].iloc[-30] if len(processed_df) >= 30 else last_row['sales'].iloc[0],
                'rolling_mean_7': processed_df['sales'].iloc[-7:].mean() if len(processed_df) >= 7 else last_row['sales'].iloc[0],
                'rolling_mean_30': processed_df['sales'].iloc[-30:].mean() if len(processed_df) >= 30 else last_row['sales'].iloc[0],
                'trend': len(processed_df) + day
            }
            
            # Create feature array
            features = np.array([[features_dict[col] for col in self.feature_columns]])
            
            # Scale features
            features_scaled = self.scaler.transform(features)
            
            # Predict
            pred_sales = self.model.predict(features_scaled)[0]
            predictions.append(max(0, pred_sales))  # Ensure non-negative
            prediction_dates.append(future_date)
            
            # Update current_data for next iteration
            current_data['sales'].iloc[0] = pred_sales
        
        return predictions, "Forecast generated successfully", prediction_dates

# Initialize forecaster
forecaster = SalesForecaster()

# Layout for sales forecasting page
layout = dbc.Container([
    dbc.Row([
        dbc.Col([
            html.H2("📈 Sales Forecasting", className="text-center mb-4 gradient-text"),
            html.P("Predict future sales using machine learning", 
                   className="text-center text-muted mb-4"),
        ], width=12)
    ], className="fade-in"),
    
    dcc.Store(id='sales-data-store', data=None),
    
    dbc.Row([
        dbc.Col([
            dbc.Card([
                dbc.CardBody([
                    html.H5("Upload Sales Data", className="card-title"),
                    html.P("Upload a CSV file with sales data. Required columns: 'date' and 'sales' (or 'value')", 
                           className="text-muted small mb-3"),
                    
                    dcc.Upload(
                        id='upload-data',
                        children=html.Div([
                            '📁 Drag and Drop or ',
                            html.A('Select CSV File')
                        ]),
                        style={
                            'width': '100%',
                            'height': '60px',
                            'lineHeight': '60px',
                            'borderWidth': '1px',
                            'borderStyle': 'dashed',
                            'borderRadius': '5px',
                            'textAlign': 'center',
                            'margin': '10px 0',
                            'cursor': 'pointer'
                        },
                        multiple=False
                    ),
                    
                    html.Hr(),
                    
                    html.H5("Or Enter Data Manually", className="card-title mt-3"),
                    html.Label("Start Date:"),
                    dcc.DatePickerSingle(
                        id='start-date',
                        date=datetime.now() - timedelta(days=365),
                        className="mb-3"
                    ),
                    
                    html.Label("Number of Days:"),
                    dcc.Input(
                        id='num-days',
                        type='number',
                        value=365,
                        min=30,
                        max=2000,
                        className="form-control mb-3"
                    ),
                    
                    html.Label("Days to Forecast:"),
                    dcc.Slider(
                        id='forecast-days-slider',
                        min=7,
                        max=90,
                        step=7,
                        value=30,
                        marks={i: str(i) for i in range(7, 91, 14)},
                        className="mb-3"
                    ),
                    
                    dbc.Button(
                        "🚀 Generate Forecast",
                        id='forecast-button',
                        color="primary",
                        className="w-100 hover-lift mt-3"
                    ),
                    
                    html.Div(id='upload-status', className="mt-3")
                ])
            ])
        ], width=4),
        
        dbc.Col([
            dbc.Card([
                dbc.CardBody([
                    html.H5("Sales Forecast Chart", className="card-title"),
                    dcc.Graph(id='forecast-chart'),
                    html.Div(id='forecast-status', className="mt-3")
                ])
            ])
        ], width=8)
    ], className="mb-4"),
    
    dbc.Row([
        dbc.Col([
            dbc.Card([
                dbc.CardBody([
                    html.H5("Model Performance Metrics", className="card-title"),
                    html.Div(id='model-metrics')
                ])
            ])
        ], width=12)
    ])
])

def parse_contents(contents, filename):
    """Parse uploaded CSV file"""
    content_type, content_string = contents.split(',')
    decoded = base64.b64decode(content_string)
    
    try:
        if 'csv' in filename:
            df = pd.read_csv(io.StringIO(decoded.decode('utf-8')))
        else:
            return None, "Please upload a CSV file"
        
        return df, None
    except Exception as e:
        return None, f"Error parsing file: {str(e)}"

# Callback for file upload
@callback(
    [Output('sales-data-store', 'data'),
     Output('upload-status', 'children')],
    [Input('upload-data', 'contents')],
    [State('upload-data', 'filename')]
)
def handle_upload(upload_contents, filename):
    if upload_contents is None:
        return None, ""
    
    df, error = parse_contents(upload_contents, filename)
    if error:
        return None, dbc.Alert(error, color="danger")
    
    if df is not None and len(df) > 0:
        # Convert DataFrame to JSON for storage
        df_dict = df.to_dict('records')
        upload_status = dbc.Alert(f"✅ File uploaded successfully: {filename} ({len(df)} rows). Click 'Generate Forecast' to proceed.", color="success")
        return df_dict, upload_status
    else:
        return None, dbc.Alert("⚠️ File uploaded but appears empty", color="warning")

# Callback for forecast generation
@callback(
    [Output('forecast-chart', 'figure'),
     Output('forecast-status', 'children'),
     Output('model-metrics', 'children')],
    [Input('forecast-button', 'n_clicks')],
    [State('sales-data-store', 'data'),
     State('start-date', 'date'),
     State('num-days', 'value'),
     State('forecast-days-slider', 'value')]
)
def update_forecast(n_clicks, stored_data, start_date, num_days, forecast_days):
    if n_clicks is None:
        return go.Figure(), "", ""
    
    # Use uploaded data if available, otherwise generate sample data
    if stored_data is not None:
        df = pd.DataFrame(stored_data)
    else:
        # Generate sample sales data
        start = pd.to_datetime(start_date)
        dates = pd.date_range(start=start, periods=num_days, freq='D')
        
        # Create realistic sales pattern with trend and seasonality
        np.random.seed(42)
        trend = np.linspace(1000, 1500, num_days)
        seasonality = 200 * np.sin(2 * np.pi * np.arange(num_days) / 365.25)
        noise = np.random.normal(0, 50, num_days)
        sales = trend + seasonality + noise
        sales = np.maximum(sales, 0)  # Ensure non-negative
        
        df = pd.DataFrame({
            'date': dates,
            'sales': sales
        })
    
    # Train model and generate forecast
    success, message, metrics = forecaster.train_model(df)
    
    if not success:
        return go.Figure(), dbc.Alert(message, color="danger"), ""
    
    # Generate forecast
    predictions, forecast_message, prediction_dates = forecaster.forecast_sales(df, forecast_days)
    
    if predictions is None:
        return go.Figure(), dbc.Alert(forecast_message, color="danger"), "", upload_status
    
    # Prepare historical data for plotting
    X, y, processed_df = forecaster.prepare_sales_data(df)
    
    # Create chart
    fig = make_subplots(
        rows=2, cols=1, 
        subplot_titles=('Sales History & Forecast', 'Forecast Details'),
        vertical_spacing=0.15,
        row_heights=[0.7, 0.3]
    )
    
    # Historical data
    fig.add_trace(
        go.Scatter(
            x=processed_df.index, 
            y=processed_df['sales'], 
            name='Historical Sales', 
            line=dict(color='blue', width=2),
            mode='lines+markers'
        ),
        row=1, col=1
    )
    
    # Forecast
    fig.add_trace(
        go.Scatter(
            x=prediction_dates, 
            y=predictions, 
            name='Forecasted Sales', 
            line=dict(color='red', dash='dash', width=2),
            mode='lines+markers'
        ),
        row=1, col=1
    )
    
    # Confidence interval (simplified - using std of predictions)
    pred_std = np.std(predictions)
    fig.add_trace(
        go.Scatter(
            x=prediction_dates + prediction_dates[::-1],
            y=list(predictions + pred_std) + list((np.array(predictions) - pred_std)[::-1]),
            fill='toself',
            fillcolor='rgba(255,0,0,0.2)',
            line=dict(color='rgba(255,255,255,0)'),
            name='Confidence Interval',
            showlegend=True
        ),
        row=1, col=1
    )
    
    # Forecast summary bar chart
    fig.add_trace(
        go.Bar(
            x=prediction_dates[::max(1, len(prediction_dates)//10)], 
            y=[predictions[i] for i in range(0, len(predictions), max(1, len(predictions)//10))],
            name='Forecast (Sampled)',
            marker_color='orange'
        ),
        row=2, col=1
    )
    
    fig.update_layout(
        height=700, 
        showlegend=True,
        hovermode='x unified'
    )
    fig.update_xaxes(title_text="Date", row=2, col=1)
    fig.update_yaxes(title_text="Sales", row=1, col=1)
    fig.update_yaxes(title_text="Forecasted Sales", row=2, col=1)
    
    # Status message
    status = dbc.Alert(f"✅ {forecast_message}", color="success")
    
    # Metrics display
    if metrics:
        metrics_html = dbc.Row([
            dbc.Col([
                dbc.Card([
                    dbc.CardBody([
                        html.H6("R² Score", className="text-muted"),
                        html.H4(f"{metrics['r2_score']:.4f}", className="text-primary")
                    ])
                ], color="light")
            ], width=3),
            dbc.Col([
                dbc.Card([
                    dbc.CardBody([
                        html.H6("RMSE", className="text-muted"),
                        html.H4(f"{metrics['rmse']:.2f}", className="text-warning")
                    ])
                ], color="light")
            ], width=3),
            dbc.Col([
                dbc.Card([
                    dbc.CardBody([
                        html.H6("MAE", className="text-muted"),
                        html.H4(f"{metrics['mae']:.2f}", className="text-info")
                    ])
                ], color="light")
            ], width=3),
            dbc.Col([
                dbc.Card([
                    dbc.CardBody([
                        html.H6("MSE", className="text-muted"),
                        html.H4(f"{metrics['mse']:.2f}", className="text-secondary")
                    ])
                ], color="light")
            ], width=3)
        ])
    else:
        metrics_html = html.P("Train the model to see metrics", className="text-muted")
    
    return fig, status, metrics_html

