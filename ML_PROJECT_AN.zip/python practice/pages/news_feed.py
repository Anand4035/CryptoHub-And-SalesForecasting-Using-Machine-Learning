import requests
import os
from datetime import datetime, timedelta
import dash
from dash import dcc, html, Input, Output, callback
import dash_bootstrap_components as dbc
from bs4 import BeautifulSoup
import time

class CryptoNewsFetcher:
    def __init__(self):
        self.news_api_key = os.getenv('NEWS_API_KEY', '')
        self.cache = {}
        self.cache_timeout = 600  # 10 minutes
        
    def get_crypto_news_from_api(self, query='cryptocurrency', language='en', sort_by='publishedAt'):
        """Fetch crypto news from NewsAPI"""
        if not self.news_api_key:
            return []
        
        cache_key = f"news_api_{query}_{language}_{sort_by}"
        
        if self._is_cache_valid(cache_key):
            return self.cache[cache_key]['data']
        
        try:
            url = "https://newsapi.org/v2/everything"
            params = {
                'q': query,
                'language': language,
                'sortBy': sort_by,
                'pageSize': 50,
                'apiKey': self.news_api_key
            }
            
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            articles = data.get('articles', [])
            
            # Cache the data
            self.cache[cache_key] = {
                'data': articles,
                'timestamp': time.time()
            }
            
            return articles
            
        except Exception as e:
            print(f"Error fetching news from API: {e}")
            return []
    
    def get_crypto_news_from_web(self):
        """Fetch crypto news from web scraping (fallback method)"""
        cache_key = "news_web"
        
        if self._is_cache_valid(cache_key):
            return self.cache[cache_key]['data']
        
        try:
            # CoinDesk RSS feed
            coinbase_news = self._scrape_coinbase_news()
            coindesk_news = self._scrape_coindesk_news()
            
            all_news = coinbase_news + coindesk_news
            
            # Cache the data
            self.cache[cache_key] = {
                'data': all_news,
                'timestamp': time.time()
            }
            
            return all_news
            
        except Exception as e:
            print(f"Error fetching news from web: {e}")
            return []
    
    def _scrape_coinbase_news(self):
        """Scrape news from Coinbase blog"""
        try:
            url = "https://blog.coinbase.com/"
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            
            response = requests.get(url, headers=headers, timeout=10)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            articles = []
            
            # Find article elements (this would need to be updated based on actual site structure)
            article_elements = soup.find_all('article', limit=10)
            
            for article in article_elements:
                title_elem = article.find('h2') or article.find('h3')
                link_elem = article.find('a')
                
                if title_elem and link_elem:
                    articles.append({
                        'title': title_elem.get_text().strip(),
                        'url': link_elem.get('href', ''),
                        'source': 'Coinbase Blog',
                        'publishedAt': datetime.now().isoformat(),
                        'description': 'Latest updates from Coinbase'
                    })
            
            return articles
            
        except Exception as e:
            print(f"Error scraping Coinbase news: {e}")
            return []
    
    def _scrape_coindesk_news(self):
        """Scrape news from CoinDesk"""
        try:
            url = "https://www.coindesk.com/"
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            
            response = requests.get(url, headers=headers, timeout=10)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            articles = []
            
            # Find headline elements
            headlines = soup.find_all(['h1', 'h2', 'h3'], limit=10)
            
            for headline in headlines:
                link_elem = headline.find('a')
                if link_elem:
                    articles.append({
                        'title': headline.get_text().strip(),
                        'url': link_elem.get('href', ''),
                        'source': 'CoinDesk',
                        'publishedAt': datetime.now().isoformat(),
                        'description': 'Breaking cryptocurrency news'
                    })
            
            return articles
            
        except Exception as e:
            print(f"Error scraping CoinDesk news: {e}")
            return []
    
    def get_all_crypto_news(self):
        """Get crypto news from all available sources"""
        # Try API first
        api_news = self.get_crypto_news_from_api()
        
        # If API fails or returns no results, try web scraping
        if not api_news:
            api_news = self.get_crypto_news_from_web()
        
        # Add some sample news if no sources work
        if not api_news:
            api_news = self._get_sample_news()
        
        return api_news
    
    def _get_sample_news(self):
        """Get sample crypto news when APIs are not available"""
        return [
            {
                'title': 'Bitcoin Reaches New All-Time High',
                'url': '#',
                'source': 'Crypto News',
                'publishedAt': datetime.now().isoformat(),
                'description': 'Bitcoin has reached a new all-time high, breaking previous records.',
                'urlToImage': 'https://via.placeholder.com/300x200?text=Bitcoin'
            },
            {
                'title': 'Ethereum 2.0 Upgrade Shows Promising Results',
                'url': '#',
                'source': 'Crypto News',
                'publishedAt': (datetime.now() - timedelta(hours=2)).isoformat(),
                'description': 'The Ethereum 2.0 upgrade continues to show positive results for the network.',
                'urlToImage': 'https://via.placeholder.com/300x200?text=Ethereum'
            },
            {
                'title': 'Major Bank Announces Cryptocurrency Services',
                'url': '#',
                'source': 'Crypto News',
                'publishedAt': (datetime.now() - timedelta(hours=4)).isoformat(),
                'description': 'A major financial institution has announced plans to offer cryptocurrency services.',
                'urlToImage': 'https://via.placeholder.com/300x200?text=Bank'
            },
            {
                'title': 'DeFi Protocol Reaches $1 Billion TVL',
                'url': '#',
                'source': 'Crypto News',
                'publishedAt': (datetime.now() - timedelta(hours=6)).isoformat(),
                'description': 'A decentralized finance protocol has reached $1 billion in total value locked.',
                'urlToImage': 'https://via.placeholder.com/300x200?text=DeFi'
            },
            {
                'title': 'NFT Market Sees Record Trading Volume',
                'url': '#',
                'source': 'Crypto News',
                'publishedAt': (datetime.now() - timedelta(hours=8)).isoformat(),
                'description': 'The NFT market has seen record trading volume this week.',
                'urlToImage': 'https://via.placeholder.com/300x200?text=NFT'
            }
        ]
    
    def _is_cache_valid(self, cache_key):
        """Check if cached data is still valid"""
        if cache_key not in self.cache:
            return False
        
        cache_time = self.cache[cache_key]['timestamp']
        return (time.time() - cache_time) < self.cache_timeout

# Initialize news fetcher
news_fetcher = CryptoNewsFetcher()

# Layout for news feed page
layout = dbc.Container([
    dbc.Row([
        dbc.Col([
            html.H2("📰 Cryptocurrency News Feed", className="text-center mb-4 gradient-text"),
            html.P("Stay updated with the latest cryptocurrency news and market developments", 
                   className="text-center text-muted mb-4"),
        ], width=12)
    ], className="fade-in"),
    
    dbc.Row([
        dbc.Col([
            dbc.Card([
                dbc.CardBody([
                    html.H5("News Filters", className="card-title"),
                    
                    dbc.Row([
                        dbc.Col([
                            html.Label("Search Keywords:"),
                            dbc.Input(
                                id='news-search',
                                placeholder="Search for specific topics...",
                                className="mb-3"
                            )
                        ], width=6),
                        
                        dbc.Col([
                            html.Label("Sort By:"),
                            dcc.Dropdown(
                                id='news-sort',
                                options=[
                                    {'label': 'Latest First', 'value': 'publishedAt'},
                                    {'label': 'Relevance', 'value': 'relevancy'},
                                    {'label': 'Popularity', 'value': 'popularity'}
                                ],
                                value='publishedAt',
                                className="mb-3"
                            )
                        ], width=6)
                    ]),
                    
                    dbc.Row([
                        dbc.Col([
                            dbc.Button(
                                "🔄 Refresh News",
                                id='refresh-news',
                                color="primary",
                                className="w-100 hover-lift"
                            )
                        ], width=6),
                        
                        dbc.Col([
                            dbc.Button(
                                "🗑️ Clear Filters",
                                id='clear-filters',
                                color="outline-secondary",
                                className="w-100 hover-lift"
                            )
                        ], width=6)
                    ])
                ])
            ])
        ], width=4),
        
        dbc.Col([
            dbc.Card([
                dbc.CardBody([
                    html.H5("Latest News", className="card-title"),
                    html.Div(id='news-feed')
                ])
            ])
        ], width=8)
    ], className="mb-4"),
    
    dbc.Row([
        dbc.Col([
            dbc.Card([
                dbc.CardBody([
                    html.H5("Trending Topics", className="card-title"),
                    html.Div(id='trending-topics')
                ])
            ])
        ], width=12)
    ])
])

def create_news_card(article):
    """Create a news card component"""
    # Format published date
    try:
        published_date = datetime.fromisoformat(article['publishedAt'].replace('Z', '+00:00'))
        formatted_date = published_date.strftime('%B %d, %Y at %I:%M %p')
    except:
        formatted_date = "Recently"
    
    # Get image URL
    image_url = article.get('urlToImage', 'https://via.placeholder.com/300x200?text=Crypto+News')
    
    return dbc.Card([
        dbc.CardBody([
            dbc.Row([
                dbc.Col([
                    html.Img(
                        src=image_url,
                        style={'width': '100%', 'height': '150px', 'object-fit': 'cover'},
                        className="rounded"
                    )
                ], width=4),
                
                dbc.Col([
                    html.H6(
                        article.get('title', 'No Title'),
                        className="card-title"
                    ),
                    
                    html.P(
                        article.get('description', 'No description available'),
                        className="card-text text-muted",
                        style={'font-size': '0.9em'}
                    ),
                    
                    html.Small([
                        html.Strong(f"Source: {article.get('source', 'Unknown')}"),
                        html.Br(),
                        html.Span(f"Published: {formatted_date}", className="text-muted")
                    ]),
                    
                    html.Br(),
                    
                    dbc.Button(
                        "Read More",
                        href=article.get('url', '#'),
                        external_link=True,
                        color="outline-primary",
                        size="sm",
                        className="mt-2"
                    )
                ], width=8)
            ])
        ])
    ], className="mb-3")

def create_news_feed(articles, search_term=''):
    """Create the news feed display"""
    if not articles:
        return dbc.Alert("No news articles found", color="warning")
    
    # Filter articles based on search term
    if search_term:
        filtered_articles = [
            article for article in articles
            if search_term.lower() in article.get('title', '').lower() or
               search_term.lower() in article.get('description', '').lower()
        ]
    else:
        filtered_articles = articles
    
    if not filtered_articles:
        return dbc.Alert(f"No articles found matching '{search_term}'", color="info")
    
    # Create news cards
    news_cards = [create_news_card(article) for article in filtered_articles[:20]]
    
    return html.Div(news_cards)

def create_trending_topics():
    """Create trending topics section"""
    topics = [
        {'name': 'Bitcoin', 'count': 45, 'trend': 'up'},
        {'name': 'Ethereum', 'count': 32, 'trend': 'up'},
        {'name': 'DeFi', 'count': 28, 'trend': 'up'},
        {'name': 'NFT', 'count': 25, 'trend': 'down'},
        {'name': 'Regulation', 'count': 22, 'trend': 'up'},
        {'name': 'CBDC', 'count': 18, 'trend': 'up'},
        {'name': 'Web3', 'count': 15, 'trend': 'up'},
        {'name': 'Staking', 'count': 12, 'trend': 'up'}
    ]
    
    topic_cards = []
    for topic in topics:
        trend_icon = "📈" if topic['trend'] == 'up' else "📉"
        
        topic_cards.append(
            dbc.Col([
                dbc.Card([
                    dbc.CardBody([
                        html.H6(f"{trend_icon} {topic['name']}", className="card-title"),
                        html.P(f"{topic['count']} articles", className="card-text text-muted")
                    ])
                ], className="h-100")
            ], width=3, className="mb-3")
        )
    
    return dbc.Row(topic_cards)

# Callbacks
@callback(
    [Output('news-feed', 'children'),
     Output('trending-topics', 'children')],
    [Input('refresh-news', 'n_clicks'),
     Input('news-search', 'value'),
     Input('news-sort', 'value')]
)
def update_news_feed(n_clicks, search_term, sort_by):
    # Fetch news
    articles = news_fetcher.get_all_crypto_news()
    
    # Sort articles
    if sort_by == 'publishedAt':
        articles.sort(key=lambda x: x.get('publishedAt', ''), reverse=True)
    elif sort_by == 'relevancy':
        # Simple relevancy based on title keywords
        crypto_keywords = ['bitcoin', 'ethereum', 'crypto', 'blockchain', 'defi', 'nft']
        articles.sort(key=lambda x: sum(1 for keyword in crypto_keywords 
                                      if keyword in x.get('title', '').lower()), reverse=True)
    
    # Create news feed
    news_feed = create_news_feed(articles, search_term or '')
    
    # Create trending topics
    trending_topics = create_trending_topics()
    
    return news_feed, trending_topics

@callback(
    [Output('news-search', 'value'),
     Output('news-sort', 'value')],
    [Input('clear-filters', 'n_clicks')]
)
def clear_filters(n_clicks):
    if n_clicks:
        return '', 'publishedAt'
    return dash.no_update, dash.no_update

