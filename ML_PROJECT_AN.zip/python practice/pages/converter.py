import requests
import pandas as pd
import plotly.graph_objs as go
from datetime import datetime, timedelta
import dash
from dash import dcc, html, Input, Output, State, callback
import dash_bootstrap_components as dbc
import time

class CryptoConverter:
    def __init__(self):
        self.base_url = "https://api.coingecko.com/api/v3"
        self.cache = {}
        self.cache_timeout = 300  # 5 minutes
        
    def get_supported_currencies(self):
        """Get list of supported cryptocurrencies"""
        cache_key = "supported_currencies"
        
        if self._is_cache_valid(cache_key):
            return self.cache[cache_key]['data']
        
        try:
            url = f"{self.base_url}/coins/list"
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            
            # Cache the data
            self.cache[cache_key] = {
                'data': data,
                'timestamp': time.time()
            }
            
            return data
            
        except Exception as e:
            print(f"Error fetching supported currencies: {e}")
            return []
    
    def get_crypto_price(self, crypto_id, vs_currency='usd'):
        """Get current price of a cryptocurrency"""
        cache_key = f"price_{crypto_id}_{vs_currency}"
        
        if self._is_cache_valid(cache_key):
            return self.cache[cache_key]['data']
        
        try:
            url = f"{self.base_url}/simple/price"
            params = {
                'ids': crypto_id,
                'vs_currencies': vs_currency,
                'include_24hr_change': True
            }
            
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            
            # Cache the data
            self.cache[cache_key] = {
                'data': data,
                'timestamp': time.time()
            }
            
            return data
            
        except Exception as e:
            print(f"Error fetching price: {e}")
            return None
    
    def convert_crypto(self, from_crypto, to_crypto, amount):
        """Convert between two cryptocurrencies or crypto to fiat"""
        try:
            # Check if to_crypto is a fiat currency
            fiat_currencies = ['usd', 'inr', 'eur', 'gbp', 'jpy', 'cad', 'aud', 'chf', 'cny', 'rub']
            
            # If target is fiat, convert crypto to fiat
            if to_crypto.lower() in fiat_currencies:
                from_price_data = self.get_crypto_price(from_crypto, vs_currency=to_crypto)
                if not from_price_data:
                    return None, "Could not fetch price data"
                
                from_price = from_price_data.get(from_crypto, {}).get(to_crypto, 0)
                if from_price == 0:
                    return None, "Invalid price data"
                
                converted_amount = amount * from_price
                return converted_amount, "Conversion successful"
            
            # Check if from_crypto is a fiat currency (convert fiat to crypto)
            if from_crypto.lower() in fiat_currencies:
                # We need inverse conversion: usd -> crypto
                # Get price in the fiat currency
                to_price_data = self.get_crypto_price(to_crypto, vs_currency=from_crypto)
                if not to_price_data:
                    return None, "Could not fetch price data"
                
                to_price = to_price_data.get(to_crypto, {}).get(from_crypto, 0)
                if to_price == 0:
                    return None, "Invalid price data"
                
                # Convert fiat to crypto
                converted_amount = amount / to_price
                return converted_amount, "Conversion successful"
            
            # Crypto to crypto conversion
            from_price_data = self.get_crypto_price(from_crypto)
            to_price_data = self.get_crypto_price(to_crypto)
            
            if not from_price_data or not to_price_data:
                return None, "Could not fetch price data"
            
            from_price = from_price_data.get(from_crypto, {}).get('usd', 0)
            to_price = to_price_data.get(to_crypto, {}).get('usd', 0)
            
            if from_price == 0 or to_price == 0:
                return None, "Invalid price data"
            
            # Convert: amount * (from_price / to_price)
            converted_amount = amount * (from_price / to_price)
            
            return converted_amount, "Conversion successful"
            
        except Exception as e:
            return None, f"Conversion error: {str(e)}"
    
    def get_price_history(self, crypto_id, days=7):
        """Get historical price data for charting"""
        cache_key = f"history_{crypto_id}_{days}"
        
        if self._is_cache_valid(cache_key):
            return self.cache[cache_key]['data']
        
        try:
            url = f"{self.base_url}/coins/{crypto_id}/market_chart"
            params = {
                'vs_currency': 'usd',
                'days': days,
                'interval': 'daily' if days > 1 else 'hourly'
            }
            
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            
            # Cache the data
            self.cache[cache_key] = {
                'data': data,
                'timestamp': time.time()
            }
            
            return data
            
        except Exception as e:
            print(f"Error fetching price history: {e}")
            return None
    
    def _is_cache_valid(self, cache_key):
        """Check if cached data is still valid"""
        if cache_key not in self.cache:
            return False
        
        cache_time = self.cache[cache_key]['timestamp']
        return (time.time() - cache_time) < self.cache_timeout

# Initialize converter
converter = CryptoConverter()

# Get popular cryptocurrencies and fiat currencies for dropdowns
popular_cryptos = [
    {'label': 'Bitcoin (BTC)', 'value': 'bitcoin'},
    {'label': 'Ethereum (ETH)', 'value': 'ethereum'},
    {'label': 'Binance Coin (BNB)', 'value': 'binancecoin'},
    {'label': 'Cardano (ADA)', 'value': 'cardano'},
    {'label': 'Solana (SOL)', 'value': 'solana'},
    {'label': 'Polkadot (DOT)', 'value': 'polkadot'},
    {'label': 'Chainlink (LINK)', 'value': 'chainlink'},
    {'label': 'Litecoin (LTC)', 'value': 'litecoin'},
    {'label': 'Bitcoin Cash (BCH)', 'value': 'bitcoin-cash'},
    {'label': 'Stellar (XLM)', 'value': 'stellar'},
    {'label': 'Dogecoin (DOGE)', 'value': 'dogecoin'},
    {'label': 'Polygon (MATIC)', 'value': 'matic-network'},
    {'label': 'Avalanche (AVAX)', 'value': 'avalanche-2'},
    {'label': 'Uniswap (UNI)', 'value': 'uniswap'},
    {'label': 'Cosmos (ATOM)', 'value': 'cosmos'},
]

# Fiat currencies
fiat_currencies = [
    {'label': 'US Dollar (USD)', 'value': 'usd'},
    {'label': 'Indian Rupee (INR)', 'value': 'inr'},
    {'label': 'Euro (EUR)', 'value': 'eur'},
    {'label': 'British Pound (GBP)', 'value': 'gbp'},
    {'label': 'Japanese Yen (JPY)', 'value': 'jpy'},
    {'label': 'Canadian Dollar (CAD)', 'value': 'cad'},
    {'label': 'Australian Dollar (AUD)', 'value': 'aud'},
    {'label': 'Swiss Franc (CHF)', 'value': 'chf'},
    {'label': 'Chinese Yuan (CNY)', 'value': 'cny'},
    {'label': 'Russian Ruble (RUB)', 'value': 'rub'},
]

# Combined list for dropdown
all_currencies = popular_cryptos + fiat_currencies

# Layout for converter page
layout = dbc.Container([
    dbc.Row([
        dbc.Col([
            html.H2("💱 Cryptocurrency Converter", className="text-center mb-4 gradient-text"),
            html.P("Convert between different cryptocurrencies with real-time rates", 
                   className="text-center text-muted mb-4"),
        ], width=12)
    ], className="fade-in"),
    
    dbc.Row([
        dbc.Col([
            dbc.Card([
                dbc.CardBody([
                    html.H5("Currency Converter", className="card-title"),
                    
                    dbc.Row([
                        dbc.Col([
                            html.Label("From:"),
                            dcc.Dropdown(
                                id='from-crypto',
                                options=all_currencies,
                                value='bitcoin',
                                className="mb-3",
                                searchable=True
                            ),
                            
                            html.Label("Amount:"),
                            dbc.Input(
                                id='amount-input',
                                type='number',
                                value=1,
                                min=0,
                                step=0.000001,
                                className="mb-3"
                            )
                        ], width=6),
                        
                        dbc.Col([
                            html.Label("To:"),
                            dcc.Dropdown(
                                id='to-crypto',
                                options=all_currencies,
                                value='usd',
                                className="mb-3",
                                searchable=True
                            ),
                            
                            html.Label("Converted Amount:"),
                            dbc.Input(
                                id='converted-amount',
                                type='text',
                                value='',
                                readonly=True,
                                className="mb-3"
                            )
                        ], width=6)
                    ]),
                    
                    dbc.Row([
                        dbc.Col([
                            dbc.Button(
                                "🔄 Convert",
                                id='convert-button',
                                color="primary",
                                className="w-100 mb-3 hover-lift"
                            )
                        ], width=6),
                        
                        dbc.Col([
                            dbc.Button(
                                "🔄 Swap Currencies",
                                id='swap-button',
                                color="outline-secondary",
                                className="w-100 mb-3 hover-lift"
                            )
                        ], width=6)
                    ]),
                    
                    html.Div(id='conversion-status')
                ])
            ])
        ], width=6),
        
        dbc.Col([
            dbc.Card([
                dbc.CardBody([
                    html.H5("Price Comparison", className="card-title"),
                    html.Div(id='price-comparison')
                ])
            ])
        ], width=6)
    ], className="mb-4"),
    
    dbc.Row([
        dbc.Col([
            dbc.Card([
                dbc.CardBody([
                    html.H5("Price History Chart", className="card-title"),
                    dcc.Graph(id='price-chart')
                ])
            ])
        ], width=12)
    ], className="mb-4"),
    
    dbc.Row([
        dbc.Col([
            dbc.Card([
                dbc.CardBody([
                    html.H5("Quick Conversions", className="card-title"),
                    html.Div(id='quick-conversions')
                ])
            ])
        ], width=12)
    ])
])

def create_price_comparison(from_crypto, to_crypto):
    """Create price comparison display"""
    try:
        from_price_data = converter.get_crypto_price(from_crypto)
        to_price_data = converter.get_crypto_price(to_crypto)
        
        if not from_price_data or not to_price_data:
            return dbc.Alert("Could not fetch price data", color="warning")
        
        from_price = from_price_data.get(from_crypto, {}).get('usd', 0)
        to_price = to_price_data.get(to_crypto, {}).get('usd', 0)
        
        from_change = from_price_data.get(from_crypto, {}).get('usd_24h_change', 0)
        to_change = to_price_data.get(to_crypto, {}).get('usd_24h_change', 0)
        
        return dbc.Row([
            dbc.Col([
                html.H6(f"{from_crypto.title()} Price"),
                html.H4(f"${from_price:,.2f}"),
                html.Span(
                    f"{from_change:+.2f}%",
                    className=f"text-{'success' if from_change >= 0 else 'danger'}"
                )
            ], width=6),
            
            dbc.Col([
                html.H6(f"{to_crypto.title()} Price"),
                html.H4(f"${to_price:,.2f}"),
                html.Span(
                    f"{to_change:+.2f}%",
                    className=f"text-{'success' if to_change >= 0 else 'danger'}"
                )
            ], width=6)
        ])
        
    except Exception as e:
        return dbc.Alert(f"Error creating price comparison: {str(e)}", color="danger")

def create_price_chart(from_crypto, to_crypto):
    """Create price history chart"""
    try:
        from_history = converter.get_price_history(from_crypto, days=7)
        to_history = converter.get_price_history(to_crypto, days=7)
        
        if not from_history or not to_history:
            return go.Figure()
        
        fig = go.Figure()
        
        # Add from crypto price
        from_prices = [point[1] for point in from_history['prices']]
        from_dates = [datetime.fromtimestamp(point[0]/1000) for point in from_history['prices']]
        
        fig.add_trace(go.Scatter(
            x=from_dates,
            y=from_prices,
            mode='lines',
            name=f"{from_crypto.title()} Price",
            line=dict(color='blue')
        ))
        
        # Add to crypto price (normalized to same scale)
        to_prices = [point[1] for point in to_history['prices']]
        to_dates = [datetime.fromtimestamp(point[0]/1000) for point in to_history['prices']]
        
        fig.add_trace(go.Scatter(
            x=to_dates,
            y=to_prices,
            mode='lines',
            name=f"{to_crypto.title()} Price",
            line=dict(color='red')
        ))
        
        fig.update_layout(
            title="7-Day Price History",
            xaxis_title="Date",
            yaxis_title="Price (USD)",
            height=400
        )
        
        return fig
        
    except Exception as e:
        return go.Figure()

def create_quick_conversions(from_crypto, to_crypto, amount):
    """Create quick conversion examples"""
    try:
        converted_amount, _ = converter.convert_crypto(from_crypto, to_crypto, amount)
        
        if converted_amount is None:
            return dbc.Alert("Could not perform conversion", color="warning")
        
        # Create quick conversion examples
        examples = [0.1, 1, 10, 100, 1000]
        
        rows = []
        for example_amount in examples:
            example_converted, _ = converter.convert_crypto(from_crypto, to_crypto, example_amount)
            if example_converted is not None:
                rows.append(
                    dbc.Row([
                        dbc.Col([
                            html.Span(f"{example_amount:,.1f} {from_crypto.title()}")
                        ], width=6),
                        dbc.Col([
                            html.Span(f"= {example_converted:,.6f} {to_crypto.title()}")
                        ], width=6)
                    ], className="mb-2")
                )
        
        return html.Div(rows)
        
    except Exception as e:
        return dbc.Alert(f"Error creating quick conversions: {str(e)}", color="danger")

# Helper function to get currency label
def get_currency_label(currency_id):
    """Get the display label for a currency"""
    for currency in all_currencies:
        if currency['value'] == currency_id:
            return currency['label']
    return currency_id.upper()

# Callbacks
@callback(
    [Output('converted-amount', 'value'),
     Output('conversion-status', 'children'),
     Output('price-comparison', 'children'),
     Output('price-chart', 'figure'),
     Output('quick-conversions', 'children')],
    [Input('convert-button', 'n_clicks')],
    [State('from-crypto', 'value'),
     State('to-crypto', 'value'),
     State('amount-input', 'value')]
)
def perform_conversion(n_clicks, from_crypto, to_crypto, amount):
    if n_clicks is None or amount is None:
        return "", "", "", go.Figure(), ""
    
    if from_crypto == to_crypto:
        return str(amount), dbc.Alert("Cannot convert to the same currency", color="warning"), "", go.Figure(), ""
    
    # Perform conversion
    converted_amount, message = converter.convert_crypto(from_crypto, to_crypto, amount)
    
    if converted_amount is None:
        status = dbc.Alert(message, color="danger")
        return "", status, "", go.Figure(), ""
    
    # Get currency labels for display
    from_label = get_currency_label(from_crypto).split('(')[0].strip()
    to_label = get_currency_label(to_crypto).split('(')[0].strip()
    
    # Format converted amount with appropriate precision
    fiat_currencies = ['usd', 'inr', 'eur', 'gbp', 'jpy', 'cad', 'aud', 'chf', 'cny', 'rub']
    if to_crypto.lower() in fiat_currencies:
        formatted_amount = f"{converted_amount:,.2f}"
        display_amount = f"{formatted_amount} {to_label}"
    else:
        formatted_amount = f"{converted_amount:,.6f}"
        display_amount = f"{formatted_amount} {to_label}"
    
    # Create status message
    status = dbc.Alert(
        f"✅ {message}",
        color="success"
    )
    
    # Create price comparison
    price_comparison = create_price_comparison(from_crypto, to_crypto)
    
    # Create price chart
    price_chart = create_price_chart(from_crypto, to_crypto)
    
    # Create quick conversions
    quick_conversions = create_quick_conversions(from_crypto, to_crypto, amount)
    
    return display_amount, status, price_comparison, price_chart, quick_conversions

@callback(
    [Output('from-crypto', 'value'),
     Output('to-crypto', 'value')],
    [Input('swap-button', 'n_clicks')],
    [State('from-crypto', 'value'),
     State('to-crypto', 'value')]
)
def swap_currencies(n_clicks, from_crypto, to_crypto):
    if n_clicks is None:
        return from_crypto, to_crypto
    
    return to_crypto, from_crypto
