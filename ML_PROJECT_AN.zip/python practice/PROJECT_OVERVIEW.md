# Crypto Hub - Machine Learning Price Prediction Platform

A comprehensive cryptocurrency platform featuring machine learning-powered price prediction, real-time market data, currency conversion, and news aggregation.

## 🚀 Features

### 1. **Price Prediction** (`pages/price_prediction.py`)
- Machine learning models using Random Forest Regressor
- Technical indicators: RSI, MACD, Moving Averages
- Real-time price prediction for multiple cryptocurrencies
- Interactive charts showing historical data and predictions

### 2. **Cryptocurrency Listings** (`pages/crypto_listings.py`)
- Real-time cryptocurrency market data
- Top cryptocurrencies by market cap
- Interactive tables with sorting and filtering
- Market overview charts and analytics
- Detailed cryptocurrency information

### 3. **Currency Converter** (`pages/converter.py`)
- Convert between different cryptocurrencies
- Real-time exchange rates
- Price comparison charts
- Quick conversion examples
- Historical price analysis

### 4. **News Feed** (`pages/news_feed.py`)
- Latest cryptocurrency news aggregation
- Multiple news sources integration
- Search and filter functionality
- Trending topics analysis
- Real-time news updates

## 🏗️ Project Structure

```
crypto-hub/
├── app.py                      # Main Dash application
├── requirements.txt            # Python dependencies
├── README.md                  # Project documentation
├── run.py                     # Startup script
├── demo.py                    # Demo script
├── env_example.txt            # Environment variables template
├── pages/                     # Application pages
│   ├── __init__.py
│   ├── price_prediction.py    # ML price prediction page
│   ├── crypto_listings.py     # Crypto market listings
│   ├── converter.py           # Currency converter
│   └── news_feed.py          # News aggregation
├── data/                      # Data processing modules
│   └── processor.py          # Crypto data processor
├── utils/                     # Utility functions
│   └── __init__.py           # Common utilities
└── models/                    # ML model storage
    └── (auto-created)        # Trained models
```

## 🛠️ Technology Stack

- **Frontend**: Dash (Python web framework)
- **Styling**: Bootstrap components
- **Charts**: Plotly interactive charts
- **ML**: Scikit-learn (Random Forest)
- **Data**: Pandas, NumPy
- **APIs**: CoinGecko, NewsAPI, Yahoo Finance
- **Caching**: Custom caching mechanism

## 📊 Machine Learning Features

### Technical Indicators
- **Moving Averages**: 7-day, 30-day, 50-day
- **RSI**: Relative Strength Index
- **MACD**: Moving Average Convergence Divergence
- **Bollinger Bands**: Price volatility indicators
- **Volume Analysis**: Volume-based indicators

### Model Training
- **Algorithm**: Random Forest Regressor
- **Features**: Price, Volume, Technical Indicators
- **Validation**: Train-test split with performance metrics
- **Persistence**: Model saving and loading

## 🔌 API Integration

### Data Sources
- **CoinGecko API**: Real-time crypto prices and market data
- **Yahoo Finance**: Historical price data via yfinance
- **NewsAPI**: Cryptocurrency news aggregation
- **Web Scraping**: Fallback news sources

### Caching Strategy
- **Time-based caching**: 5-10 minute cache for API calls
- **Memory efficient**: Automatic cache invalidation
- **Fallback mechanisms**: Sample data when APIs fail

## 🚀 Getting Started

### Prerequisites
- Python 3.8 or higher
- pip package manager

### Installation

1. **Clone or download the project**
2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Set up environment variables** (optional):
   ```bash
   cp env_example.txt .env
   # Edit .env and add your API keys
   ```

4. **Run the application**:
   ```bash
   python app.py
   # or
   python run.py
   ```

5. **Open your browser**:
   Navigate to `http://localhost:8050`

### Quick Demo
```bash
python demo.py
```

## 🔑 API Keys (Optional)

### Required for Full Functionality
- **NewsAPI**: Get from https://newsapi.org/
- **CoinGecko**: Free tier available at https://www.coingecko.com/en/api

### Environment Variables
```bash
NEWS_API_KEY=your_news_api_key_here
COINGECKO_API_KEY=your_coingecko_api_key_here
```

## 📈 Usage Examples

### Price Prediction
1. Select a cryptocurrency (Bitcoin, Ethereum, etc.)
2. Choose prediction timeframe (1-30 days)
3. Click "Generate Prediction"
4. View interactive chart with predictions

### Currency Conversion
1. Select source and target cryptocurrencies
2. Enter amount to convert
3. View real-time conversion rate
4. See price comparison charts

### Market Analysis
1. Browse top cryptocurrencies by market cap
2. Sort by various metrics
3. View detailed cryptocurrency information
4. Analyze market trends and patterns

## 🎯 Key Features Explained

### Machine Learning Pipeline
1. **Data Collection**: Fetch historical price data
2. **Feature Engineering**: Calculate technical indicators
3. **Model Training**: Train Random Forest on historical data
4. **Prediction**: Generate future price predictions
5. **Visualization**: Display results in interactive charts

### Real-time Data Processing
1. **API Integration**: Multiple data sources
2. **Caching**: Efficient data caching
3. **Error Handling**: Graceful fallbacks
4. **Performance**: Optimized for speed

### User Interface
1. **Responsive Design**: Works on all devices
2. **Interactive Charts**: Plotly-powered visualizations
3. **Real-time Updates**: Live data refresh
4. **Intuitive Navigation**: Easy page switching

## 🔧 Customization

### Adding New Cryptocurrencies
Edit the dropdown options in each page module to include new cryptocurrencies.

### Modifying ML Models
Update the `CryptoPredictor` class in `pages/price_prediction.py` to use different algorithms or features.

### Adding News Sources
Extend the `CryptoNewsFetcher` class in `pages/news_feed.py` to include additional news sources.

## 📊 Performance Considerations

- **Caching**: Reduces API calls and improves speed
- **Lazy Loading**: Data loaded only when needed
- **Error Handling**: Graceful degradation when services fail
- **Memory Management**: Efficient data structures

## 🐛 Troubleshooting

### Common Issues
1. **API Rate Limits**: Add delays between requests
2. **Missing Dependencies**: Run `pip install -r requirements.txt`
3. **Port Conflicts**: Change port in `app.py`
4. **API Key Issues**: Check `.env` file configuration

### Debug Mode
Run with debug enabled:
```python
app.run_server(debug=True)
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is open source and available under the MIT License.

## 🙏 Acknowledgments

- CoinGecko for cryptocurrency data API
- NewsAPI for news aggregation
- Yahoo Finance for historical data
- Dash team for the web framework
- Scikit-learn for machine learning tools



