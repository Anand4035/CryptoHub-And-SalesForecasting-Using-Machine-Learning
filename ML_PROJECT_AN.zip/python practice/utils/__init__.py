import os
import requests
import time
from datetime import datetime

class APICache:
    """Simple caching mechanism for API calls"""
    
    def __init__(self, timeout=300):
        self.cache = {}
        self.timeout = timeout
    
    def get(self, key):
        """Get cached data if still valid"""
        if key in self.cache:
            data, timestamp = self.cache[key]
            if time.time() - timestamp < self.timeout:
                return data
            else:
                del self.cache[key]
        return None
    
    def set(self, key, data):
        """Cache data with timestamp"""
        self.cache[key] = (data, time.time())
    
    def clear(self):
        """Clear all cached data"""
        self.cache.clear()

def format_currency(amount, currency='USD'):
    """Format currency amount for display"""
    if amount >= 1:
        return f"${amount:,.2f}"
    else:
        return f"${amount:.6f}"

def format_percentage(value):
    """Format percentage with appropriate color class"""
    if value >= 0:
        return f"+{value:.2f}%", "success"
    else:
        return f"{value:.2f}%", "danger"

def format_large_number(number):
    """Format large numbers with appropriate suffixes"""
    if number >= 1e12:
        return f"{number/1e12:.2f}T"
    elif number >= 1e9:
        return f"{number/1e9:.2f}B"
    elif number >= 1e6:
        return f"{number/1e6:.2f}M"
    elif number >= 1e3:
        return f"{number/1e3:.2f}K"
    else:
        return f"{number:.2f}"

def get_api_key(service):
    """Get API key from environment variables"""
    return os.getenv(f"{service.upper()}_API_KEY", "")

def validate_api_response(response):
    """Validate API response and return data or None"""
    try:
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"API request failed: {e}")
        return None
    except ValueError as e:
        print(f"Invalid JSON response: {e}")
        return None

def get_timestamp():
    """Get current timestamp"""
    return datetime.now().isoformat()

def parse_date(date_string):
    """Parse date string and return datetime object"""
    try:
        if 'T' in date_string:
            return datetime.fromisoformat(date_string.replace('Z', '+00:00'))
        else:
            return datetime.fromisoformat(date_string)
    except:
        return datetime.now()



