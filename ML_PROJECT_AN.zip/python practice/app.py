import os
import dash
from dash import dcc, html, Input, Output, State, callback
import dash_bootstrap_components as dbc
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Import pages
import pages.price_prediction as price_prediction
import pages.crypto_listings as crypto_listings
import pages.converter as converter
import pages.news_feed as news_feed
import pages.sales_forecasting as sales_forecasting

# Initialize Dash app
app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])
app.title = "Crypto Hub - ML Price Prediction"

# Add custom CSS
app.index_string = '''
<!DOCTYPE html>
<html>
    <head>
        {%metas%}
        <title>{%title%}</title>
        {%favicon%}
        {%css%}
        <link rel="stylesheet" href="/assets/custom.css">
    </head>
    <body>
        {%app_entry%}
        <footer>
            {%config%}
            {%scripts%}
            {%renderer%}
        </footer>
    </body>
</html>
'''

# Define the layout
app.layout = dbc.Container([
    dbc.Row([
        dbc.Col([
            # Header
            html.Div([
                html.H1(" Crypto Hub ", className="gradient-text"),
                html.P("Machine Learning Powered Cryptocurrency Analysis Platform", 
                       className="text-center text-muted mb-0")
            ], className="app-header fade-in"),
            
            # Navigation
            html.Div(id='navigation', className="mb-4"),
            
            # Page content
            dcc.Location(id='url', refresh=False),
            html.Div(id='page-content', className="fade-in")
            
        ], width=12)
    ])
], fluid=True, className="main-container")

# Callback for navigation active state
@callback(Output('navigation', 'children'),
          Input('url', 'pathname'))
def update_navigation(pathname):
    return dbc.Nav([
        dbc.NavItem(dbc.NavLink("🔮 Price Prediction", href="/", active=pathname == '/')),
        dbc.NavItem(dbc.NavLink("📊 Crypto Listings", href="/listings", active=pathname == '/listings')),
        dbc.NavItem(dbc.NavLink("💱 Currency Converter", href="/converter", active=pathname == '/converter')),
        dbc.NavItem(dbc.NavLink("📰 Crypto News", href="/news", active=pathname == '/news')),
        dbc.NavItem(dbc.NavLink("📈 Sales Forecasting", href="/sales", active=pathname == '/sales')),
    ], pills=True, className="nav-pills")

# Callback for page routing
@callback(Output('page-content', 'children'),
          Input('url', 'pathname'))
def display_page(pathname):
    if pathname == '/':
        return price_prediction.layout
    elif pathname == '/listings':
        return crypto_listings.layout
    elif pathname == '/converter':
        return converter.layout
    elif pathname == '/news':
        return news_feed.layout
    elif pathname == '/sales':
        return sales_forecasting.layout
    else:
        return price_prediction.layout

if __name__ == '__main__':
    app.run(debug=False, host='127.0.0.1', port=8050)
